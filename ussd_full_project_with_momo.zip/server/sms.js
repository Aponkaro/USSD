require('dotenv').config();
const fetch = require('node-fetch');

const provider = process.env.USE_SMS_PROVIDER || 'mock';

async function sendSms(to, message) {
  if (provider === 'twilio') {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_FROM_NUMBER;
    if (!sid || !token || !from) {
      console.log('[SMS MOCK - Twilio missing creds] to=', to, 'msg=', message);
      return { mock: true };
    }
    const auth = Buffer.from(`${sid}:${token}`).toString('base64');
    const resp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${auth}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({ From: from, To: to, Body: message })
    });
    return resp.json();
  }

  if (provider === 'africastalking') {
    const username = process.env.AT_USERNAME;
    const apikey = process.env.AT_API_KEY;
    const from = process.env.AT_FROM_NUMBER || undefined;
    if (!username || !apikey) {
      console.log('[SMS MOCK - AfricasTalking missing creds] to=', to, 'msg=', message);
      return { mock: true };
    }
    const url = 'https://api.africastalking.com/version1/messaging';
    const payload = new URLSearchParams({ username, to, message });
    if (from) payload.append('from', from);
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'apiKey': apikey, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: payload
    });
    return resp.json();
  }

  // fallback mock
  console.log('[SMS MOCK] to=', to, 'msg=', message);
  return { mock: true };
}

module.exports = { sendSms };
