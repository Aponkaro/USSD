require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const ussdRouter = require('./ussd-router');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// USSD webhook
app.post('/ussd', ussdRouter);

// Simple admin endpoints (protected by ADMIN_TOKEN header for demo)
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'changeme123';

app.get('/admin/sessions', (req, res) => {
  if (req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({ error: 'unauthorized' });
  const rows = db.prepare('SELECT * FROM sessions ORDER BY last_updated DESC LIMIT 200').all();
  res.json(rows);
});

app.get('/admin/transactions', (req, res) => {
  if (req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return res.status(401).json({ error: 'unauthorized' });
  const rows = db.prepare('SELECT * FROM transactions ORDER BY created_at DESC LIMIT 500').all();
  res.json(rows);
});

app.get('/', (req, res) => res.send('USSD Service running. POST /ussd for gateway calls.'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`USSD service listening on ${PORT}`));
