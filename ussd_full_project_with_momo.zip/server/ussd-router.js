require('dotenv').config();
const express = require('express');
const uuid = require('uuid');
const db = require('./db');
const { sendSms } = require('./sms');

const router = express.Router();

function now() { return Math.floor(Date.now()/1000); }

function saveSession(sessionId, phone, serviceCode, text) {
  const upsert = db.prepare(`INSERT OR REPLACE INTO sessions (id, phone, service_code, current_text, last_updated) VALUES (?,?,?,?,?)`);
  upsert.run(sessionId, phone, serviceCode, text, now());
}

function logTransaction(sessionId, type, details, phone) {
  const stmt = db.prepare('INSERT INTO transactions (id, session_id, type, details, phone, created_at) VALUES (?,?,?,?,?,?)');
  const id = uuid.v4();
  stmt.run(id, sessionId, type, details, phone, now());
  return id;
}

// helper responses
function ussdContinue(res, message) { res.type('text/plain').send('CON ' + message); }
function ussdEnd(res, message) { res.type('text/plain').send('END ' + message); }

// main handler (support common gateway params)
router.post('/', async (req, res) => {
  const { sessionId, serviceCode, phoneNumber, text } = req.body;
  const sess = sessionId || req.body.session_id || req.body.session || uuid.v4();
  const svc = serviceCode || req.body.serviceCode || req.body.service_code || process.env.SERVICE_CODE;
  const phone = phoneNumber || req.body.msisdn || req.body.phoneNumber || req.body.phone || 'UNKNOWN';
  const userText = (typeof text !== 'undefined') ? text : (req.body.text || '');

  const input = (userText || '').trim();
  saveSession(sess, phone, svc, input);

  const parts = input === '' ? [] : input.split('*');

  // root menu
  if (parts.length === 0) {
    const menu = [
      'Welcome to CheapBundles & Services',
      '1. Buy cheap non-expiry data bundles',
      '2. Renew DSTV subscription',
      '3. Results checker (BECE / WASSCE)',
      '4. MTN AFA registration',
      '5. Contact & Info'
    ].join('\n');
    return ussdContinue(res, menu);
  }

  const choice = parts[0];

  // Data bundles
  if (choice === '1') {
    if (parts.length === 1) return ussdContinue(res, ['Choose data plan:', '1. 250MB - GHS 1.00 (No expiry)', '2. 500MB - GHS 1.50 (No expiry)', '3. 1GB - GHS 2.50 (No expiry)', '4. 2.5GB - GHS 5.00 (No expiry)', '5. 5GB - GHS 9.00 (No expiry)'].join('\n'));
    const planMap = { '1': {name: '250MB', price: 'GHS 1.00'}, '2': {name: '500MB', price: 'GHS 1.50'}, '3': {name: '1GB', price: 'GHS 2.50'}, '4': {name: '2.5GB', price: 'GHS 5.00'}, '5': {name: '5GB', price: 'GHS 9.00'} };
    const plan = planMap[parts[1]];
    if (!plan) return ussdEnd(res, 'Invalid selection.');
    if (parts.length === 2) return ussdContinue(res, `You chose ${plan}. Enter recipient phone (0 for self):`);
    const recipient = parts[2] === '0' ? phone : parts[2];
    const txId = logTransaction(sess, 'data_purchase', JSON.stringify({ plan, recipient }), phone);
    const msg = `Your ${plan} voucher (tx:${txId}) will be delivered to ${recipient}. Contact +233246116269 for queries.`;
    try { await sendSms(recipient, msg); } catch(e){ console.error(e); }
    return ussdEnd(res, `Success! ${plan} sent to ${recipient}.`);
  }

  // DSTV
  if (choice === '2') {
    if (parts.length === 1) return ussdContinue(res, 'Enter DSTV smartcard number:');
    const smartcard = parts[1];
    if (parts.length === 2) return ussdContinue(res, `Smartcard ${smartcard}\nEnter amount to pay:`);
    const amount = parts[2];
    const txId = logTransaction(sess, 'dstv_renewal', JSON.stringify({ smartcard, amount }), phone);
    const msg = `DSTV renewal (tx:${txId}) for ${smartcard} of amount ${amount} is recorded. Contact +233246116269.`;
    try { await sendSms(phone, msg); } catch(e){ console.error(e); }
    return ussdEnd(res, 'DSTV renewal successful. Confirmation sent via SMS.');
  }

  // Results
  if (choice === '3') {
    if (parts.length === 1) return ussdContinue(res, ['Results checker:', '1. BECE', '2. WASSCE'].join('\n'));
    const examChoice = parts[1];
    if (!['1','2'].includes(examChoice)) return ussdEnd(res, 'Invalid selection.');
    if (parts.length === 2) return ussdContinue(res, 'Enter index number:');
    const indexNo = parts[2];
    if (parts.length === 3) return ussdContinue(res, 'Enter exam year (e.g., 2024):');
    const year = parts[3];
    // mock result
    const examName = examChoice === '1' ? 'BECE' : 'WASSCE';
    const mockResult = examChoice === '1' ? `BECE: ${indexNo} - PASS - A A B C` : `WASSCE: ${indexNo} - ${year} - Aggreg: 18 - PASSED`;
    const txId = logTransaction(sess, 'result_request', JSON.stringify({ examName, indexNo, year }), phone);
    try { await sendSms(phone, `Result ${indexNo} (${year}): ${mockResult}`); } catch(e){ console.error(e); }
    return ussdEnd(res, 'Result sent via SMS. Contact +233246116269 if not received.');
  }

  // MTN AFA registration
  if (choice === '4') {
    if (parts.length === 1) return ussdContinue(res, 'MTN AFA Registration\nEnter full name:');
    const fullname = parts[1];
    if (parts.length === 2) return ussdContinue(res, 'Enter MTN phone number (e.g., 024xxxxxxx):');
    const mtnPhone = parts[2];
    const txId = logTransaction(sess, 'mtn_afa', JSON.stringify({ fullname, mtnPhone }), phone);
    try { await sendSms(mtnPhone, `MTN AFA registration received (tx:${txId}). Contact +233246116269`); } catch(e){ console.error(e); }
    return ussdEnd(res, 'MTN AFA registration submitted. Check SMS for confirmation.');
  }

  // Contact info
  if (choice === '5') {
    const info = [`Cheap & non-expiry data bundles`, `DSTV renewal, Results checkers, MTN AFA registration`, `Dial ${process.env.SERVICE_CODE || '*203*111*3444#'} or contact +233246116269`].join('\n');
    return ussdEnd(res, info);
  }

  return ussdEnd(res, 'Invalid option. Thank you.');
});

module.exports = router;
