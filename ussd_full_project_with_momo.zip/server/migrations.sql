CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  phone TEXT,
  service_code TEXT,
  current_text TEXT,
  last_updated INTEGER
);

CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY,
  session_id TEXT,
  type TEXT,
  details TEXT,
  phone TEXT,
  created_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_transactions_phone ON transactions(phone);
