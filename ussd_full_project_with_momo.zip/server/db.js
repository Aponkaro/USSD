// db.js: run `node db.js migrate` to create sqlite file and tables
require('dotenv').config();
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const DB_FILE = process.env.SQLITE_FILE || path.join(__dirname, 'data', 'ussd.sqlite');
const MIGRATION_SQL = fs.readFileSync(path.join(__dirname, 'migrations.sql'), 'utf8');

if (require.main === module) {
  // CLI: migrate
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const db = new Database(DB_FILE);
  db.exec(MIGRATION_SQL);
  console.log('Migrated DB at', DB_FILE);
  process.exit(0);
}

const db = new Database(DB_FILE);
module.exports = db;
