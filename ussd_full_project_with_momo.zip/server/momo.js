/**
 * MTN Mobile Money (MoMo) integration scaffold (sandbox-ready)
 *
 * This file provides helper functions to:
 *  - create a payment request (collect money) using MoMo API
 *  - check transaction status
 *
 * IMPORTANT:
 *  - Replace placeholders with your production credentials and endpoints.
 *  - In production, store secrets securely (vault/secret manager) and verify callbacks.
 *
 * Example usage:
 *   const { createPayment, getTransactionStatus } = require('./momo');
 *   await createPayment('+233501234567', 5.00, 'Purchase 1GB data');
 *
 * This is a scaffold only — you must register with MTN (or your operator) to get credentials.
 */

require('dotenv').config();
const fetch = require('node-fetch');

const MTN_BASE = process.env.MOMO_BASE_URL || 'https://sandbox.momodeveloper.mtn.com'; // sandbox base
const API_USER = process.env.MOMO_API_USER || '';   // API user (if required)
const API_KEY = process.env.MOMO_API_KEY || '';     // API key / subscription key
const CALLBACK_URL = process.env.MOMO_CALLBACK_URL || ''; // Your webhook to receive payment notifications

async function getAuthToken() {
  // Example: some MoMo sandboxes require you to exchange API_KEY for a token.
  // This is provider-specific — adapt to the documentation you receive.
  if (!API_KEY) {
    console.log('[MoMo MOCK] missing API_KEY - running in mock mode');
    return 'MOCK_TOKEN';
  }
  // Real implementation would call the token endpoint. Below is a placeholder pattern.
  const resp = await fetch(`${MTN_BASE}/collection/token/`, {
    method: 'POST',
    headers: {
      'Ocp-Apim-Subscription-Key': API_KEY,
      'Content-Type': 'application/json'
    }
  });
  if (!resp.ok) {
    throw new Error('Failed to obtain MoMo token: ' + resp.status);
  }
  const json = await resp.json();
  return json.access_token || json.token || 'MOCK_TOKEN';
}

async function createPayment(msisdn, amount, description) {
  /**
   * Creates a payment (request to pay) for the customer's phone.
   * Replace endpoint paths and payload keys with those from your MoMo vendor docs.
   */
  if (!API_KEY) {
    console.log(`[MoMo MOCK] createPayment to=${msisdn} amount=${amount} desc=${description}`);
    // Simulate a request id
    return { mock: true, transactionId: 'mock-' + Date.now() };
  }

  const token = await getAuthToken();
  const orderRef = 'order_' + Date.now();
  const payload = {
    amount: amount.toString(),
    currency: 'GHS',
    externalId: orderRef,
    payer: { partyIdType: 'MSISDN', partyId: msisdn },
    payerMessage: description,
    payeeNote: description,
    callbackUrl: CALLBACK_URL
  };

  const resp = await fetch(`${MTN_BASE}/collection/v1_0/requesttopay`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Ocp-Apim-Subscription-Key': API_KEY
    },
    body: JSON.stringify(payload)
  });

  if (!resp.ok) {
    const txt = await resp.text();
    throw new Error('MoMo createPayment failed: ' + resp.status + ' - ' + txt);
  }
  const json = await resp.json();
  return { mock: false, transactionId: json.transactionId || json.id || orderRef, raw: json };
}

async function getTransactionStatus(transactionId) {
  if (!API_KEY) {
    console.log('[MoMo MOCK] getTransactionStatus', transactionId);
    return { mock: true, status: 'SUCCESS' };
  }
  const token = await getAuthToken();
  const resp = await fetch(`${MTN_BASE}/collection/v1_0/requesttopay/${transactionId}`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      'Ocp-Apim-Subscription-Key': API_KEY
    }
  });
  if (!resp.ok) {
    throw new Error('MoMo status check failed: ' + resp.status);
  }
  return resp.json();
}

module.exports = { createPayment, getTransactionStatus };
