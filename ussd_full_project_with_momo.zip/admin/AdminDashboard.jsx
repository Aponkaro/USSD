import React, { useEffect, useState } from 'react';

export default function AdminDashboard({ apiBase = '', token = 'changeme123' }) {
  const [sessions, setSessions] = useState([]);
  const [txs, setTxs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const headers = { 'Authorization': `Bearer ${token}` };

  async function fetchData() {
    try {
      setLoading(true);
      const s = await fetch(`${apiBase}/admin/sessions`, { headers });
      if (!s.ok) throw new Error('sessions fetch failed');
      const sessionsJson = await s.json();
      const t = await fetch(`${apiBase}/admin/transactions`, { headers });
      if (!t.ok) throw new Error('transactions fetch failed');
      const txJson = await t.json();
      setSessions(sessionsJson);
      setTxs(txJson);
    } catch (e) {
      setError(e.message);
    } finally { setLoading(false); }
  }

  useEffect(() => { fetchData(); }, []);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">USSD Service Admin</h1>
      <div className="mb-4">Quick contact: +233246116269</div>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Sessions</h2>
          {loading ? <div>Loading...</div> : null}
          {error ? <div className="text-red-600">{error}</div> : null}
          <div className="space-y-2 max-h-96 overflow-auto">
            {sessions.map(s => (
              <div key={s.id} className="p-2 border rounded">
                <div className="text-sm">Phone: {s.phone}</div>
                <div className="text-xs text-gray-600">Last: {new Date(s.last_updated*1000).toLocaleString()}</div>
                <div className="text-sm truncate">Text: {s.current_text}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Transactions</h2>
          <div className="space-y-2 max-h-96 overflow-auto">
            {txs.map(tx => (
              <div key={tx.id} className="p-2 border rounded">
                <div className="text-sm">Type: {tx.type}</div>
                <div className="text-xs">Phone: {tx.phone}</div>
                <div className="text-xs">Time: {new Date(tx.created_at*1000).toLocaleString()}</div>
                <div className="text-xs truncate">Details: {tx.details}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-6">
        <button className="px-4 py-2 rounded-2xl border" onClick={fetchData}>Refresh</button>
      </div>
    </div>
  );
}
