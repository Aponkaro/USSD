# USSD Service Full Project

This project is a ready-to-run demo USSD service implementing:

- Configurable short code (default *203*111*3444#)
- SQLite persistence for sessions and transactions
- SMS adapter (mock / Twilio / Africa's Talking)
- Admin endpoints and single-file React admin dashboard component
- Dockerfile and docker-compose for local development

## Quick start

1. Copy `server/.env.example` to `server/.env` and fill values.
2. In `server/` run `npm install`.
3. Run `node db.js migrate` to create the SQLite DB (or `npm run migrate`).
4. Start server `npm start` (or `docker-compose up --build`).
5. Expose `/ussd` to your USSD gateway. The server accepts common gateway fields: `sessionId`, `serviceCode`, `phoneNumber`, `text`.

## Admin UI

Drop `admin/AdminDashboard.jsx` into your React app and pass `apiBase` and `token` props.

## Notes

- This is a demo. Do not use in production without proper security, validation, HTTPS, signature verification, production DB, and payment integrations.
- To actually deliver data bundles or renew DSTV you must integrate with operator/vendor APIs and payment systems.

Contact: +233246116269


## Mobile Money (MTN MoMo) scaffold

A scaffold for MTN Mobile Money (MoMo) integration is provided in `server/momo.js`.
It contains two helper functions:

- `createPayment(msisdn, amount, description)` - initiate a request-to-pay to the customer's phone.
- `getTransactionStatus(transactionId)` - check the status of a payment request.

**Sandbox notes**
- Set `MOMO_BASE_URL` to the sandbox base URL (default is `https://sandbox.momodeveloper.mtn.com`).
- Set `MOMO_API_KEY` and `MOMO_CALLBACK_URL` in `server/.env` with values from your MoMo sandbox account.
- The scaffold is provider-specific; adapt header names and payload fields to the documentation you receive from MTN or your aggregator.

Example usage in USSD flow:
1. User chooses a data plan costing GHS 2.50.
2. USSD asks: "Pay now using Mobile Money? 1. Yes 2. No"
3. If yes, call `createPayment(msisdn, 2.50, 'Buy 1GB no-expiry')` and show confirmation.

## Git / GitHub push instructions

To create a GitHub repository and push this project, run the following commands from the project root:

```bash
cd path/to/ussd_full_project
git init
git add .
git commit -m "Initial commit: USSD service with SMS and MoMo scaffold"
# Create a repo on GitHub (replace <username> and <repo>)
# Example using GitHub CLI:
gh repo create <username>/ussd-service --public --description "USSD service for data bundles, DSTV, results, MTN AFA"
git branch -M main
git remote add origin https://github.com/<username>/ussd-service.git
git push -u origin main
```

If you don't have the GitHub CLI, create a repo manually at https://github.com/new then run:

```bash
git remote add origin https://github.com/<username>/ussd-service.git
git push -u origin main
```

Make sure you add `.env` to `.gitignore` before pushing credentials.

