# GitHub push helper

# 1) Initialize git and commit
git init
git add .
git commit -m "Initial commit: USSD service with SMS and MoMo scaffold"

# 2) Create a GitHub repo (example using gh CLI)
# gh repo create yourusername/ussd-service --public --description "USSD service for bundles"

# 3) Push to GitHub
# git branch -M main
# git remote add origin https://github.com/yourusername/ussd-service.git
# git push -u origin main
